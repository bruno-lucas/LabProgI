/*
|---------------------------|
|Laboratório de Programação |
|---------------------------|
 */


/*
|----------------------------------------------|
|Bruno Guilherme Ricci Lucas      n USP 4460596
|Andre Luiz Abdalla Silveira 	  n USP 8030353
|Matheus Takeshi Yabiku		  n USP 7629949
|----------------------------------------------|
 */

#ifndef resultante
#define resultante

#include <math.h>
#define A 40e11

/* recebe a posição e massa de um corpo1, posição e massa de outro corpo2 e calcula a força gravitacional no corpo 1*/
/* (apenas intensidade) */
double gravit(double x1, double y1, double m1, double x2, double y2, double m2);

/* decompõe a força nos eixos x e y, respectivamente */
double resx(double F, double x1, double y1, double x2, double y2, int acel);

double resy(double F, double x1, double y1, double x2, double y2, int acel);

#endif
