#include "xwc.h"
#include <stdio.h>

int main(int argc, char const *argv[]) {
	int k = 0, key;
	WINDOW *w1;
	w1 = InitGraph(801,801, "Sky.xpm");

	while (k != 50) {
		key = WGetKey(w1);
		printf("tecla: %d\n", key);
		//key = WLastKeySym();
		//printf("tecla: %d\n", key);
		k++;
	}
	return 0;
}